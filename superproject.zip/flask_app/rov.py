from werkzeug.security import generate_password_hash, check_password_hash
a = '123456789abcdef'
print(generate_password_hash(a))