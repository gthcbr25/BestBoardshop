import sqlalchemy
from .db_session import SqlAlchemyBase


class Board(SqlAlchemyBase):
    __tablename__ = 'boards'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    price = sqlalchemy.Column(sqlalchemy.Float, nullable=True)
    about = sqlalchemy.Column(sqlalchemy.String, unique=True, nullable=True)
    photo = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    in_stock = sqlalchemy.Column(sqlalchemy.Boolean, default=True)
