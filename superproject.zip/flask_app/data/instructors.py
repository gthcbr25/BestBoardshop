import sqlalchemy
from .db_session import SqlAlchemyBase


class Instructor(SqlAlchemyBase):
    __tablename__ = 'instructor'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    price = sqlalchemy.Column(sqlalchemy.Float, nullable=True)
    about = sqlalchemy.Column(sqlalchemy.String, unique=True, nullable=True)
    in_stock = sqlalchemy.Column(sqlalchemy.Boolean, default=True)
    photo = sqlalchemy.Column(sqlalchemy.String, default=True)


