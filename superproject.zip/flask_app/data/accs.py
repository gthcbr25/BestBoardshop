import sqlalchemy
from .db_session import SqlAlchemyBase


class Accs(SqlAlchemyBase):
    __tablename__ = 'accs'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    email = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    password = sqlalchemy.Column(sqlalchemy.String, unique=True, nullable=True)
    cart = sqlalchemy.Column(sqlalchemy.String, default=True)
