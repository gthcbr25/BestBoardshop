import datetime
import smtplib

from flask import Flask, render_template, url_for
from data import db_session
from data.boards import Board
from data.instructors import Instructor
from data.accs import Accs
from flask_login import LoginManager, login_user
from flask_wtf import FlaskForm
from werkzeug.utils import redirect
from wtforms import BooleanField, PasswordField
from wtforms.fields.html5 import EmailField, SearchField
from wtforms.validators import DataRequired
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
db_session.global_init("db/products.db")
acc = []


login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(Accs).get(user_id)


class LoginForm(FlaskForm):
    email = EmailField('Email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember me')


@app.route('/')
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(Accs).filter(Accs.email == form.email.data).first()
        if user and check_password_hash(user.password, form.password.data):
            db_sess = db_session.create_session()
            b = db_sess.query(Board).all()
            return redirect(url_for('index1', user=user.name))
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', form=form)


@app.route('/index/<user>')
def index1(user):
    db_sess = db_session.create_session()
    b = db_sess.query(Board).all()
    return render_template('index1.html', board=b, ak=user)


@app.route('/cart/<user>/<arg>')
def cart(user, arg):
    global acc
    db_sess = db_session.create_session()
    b = db_sess.query(Board).all()
    i = db_sess.query(Instructor).all()
    acc = db_sess.query(Accs).all()
    a = 0
    for j in acc:
        a += 1
        if j.name == user:
            q = j.email
            acc = j.cart.split(',')
            break
    if arg == '2':
        acc = []
        account = db_sess.query(Accs).filter(Accs.name == user).first()
        account.cart = ''
        db_sess.commit()
    elif arg != '1':
        acc.append(arg)
        account = db_sess.query(Accs).filter(Accs.name == user).first()
        account.cart = ', '.join(acc)
        db_sess.commit()
    return render_template('carting.html', board=b, ak=user, inst=i, acc=acc)


@app.route('/about/<user>')
def about(user):
    return render_template('about.html', ak=user)


@app.route('/profile/<user>')
def profile(user):
    db_sess = db_session.create_session()
    b = db_sess.query(Accs).all()
    return render_template('profile.html', ak=user, inf=b)


@app.route('/specials/<user>')
def specials(user):
    db_sess = db_session.create_session()
    b = db_sess.query(Instructor).all()
    for i in b:
        print(i.photo)
    return render_template('specials.html', board=b, ak=user)


@app.route('/information/<user>/<item>')
def information(user, item):
    db_sess = db_session.create_session()
    b = db_sess.query(Board).all()
    i = db_sess.query(Instructor).all()
    for j in b:
        if j.name == item:
            b = b
            break
    for j in i:
        if j.name == item:
            b = i
    return render_template('information.html', board=b, ak=user, q=item)

# |  В
# |  О
# |  Т
# V


class RegisterForm(FlaskForm):
    name = SearchField('Name', validators=[DataRequired()])
    email = EmailField('Email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])


@app.route('/register', methods=['GET', 'POST'])
def reg():
    form = RegisterForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        if db_sess.query(Accs).filter(Accs.email == form.email.data).first():
            return render_template('register.html', message="Данный email уже был зарегистрирован", form=form)
        if len(form.password.data) < 6:
            return render_template('register.html', message="Слишком короткий пароль", form=form)
        db_sess = db_session.create_session()
        person = Accs(name=form.name.data, email=form.email.data, password=generate_password_hash(form.password.data),
                      cart=',')
        db_sess.add(person)
        db_sess.commit()
        return redirect(url_for('login'))
    return render_template('register.html', form=form)


def main():
    app.run()


if __name__ == '__main__':
    main()
